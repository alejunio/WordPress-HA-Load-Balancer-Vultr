#!/bin/bash 
#
# init.sh - Pre configuracao de servidor
#
# Site       : https://alexjunio.com.br/
# Autor      : Alex Junio <contato@alexjunio.com.br>
# 
# ---------------------------------------------------------


# Cores
red=`echo -en "\e[31m"`
normal=`echo -en "\e[0m"`
green=`echo -en "\e[32m"`
orange=`echo -en "\e[33m"`
blue=`echo -en "\e[34m"`
bold=`echo -en "\e[1m"`

# INSTALACAO ANSIBLE
apt update 
apt-get install python3 git unzip htop -y
apt install software-properties-common -y
apt-add-repository --yes --update ppa:ansible/ansible
apt install ansible -y 

# CONFIGURACAO HOST ANSIBLE
cd /etc/ansible/ && rm hosts

cat > /etc/ansible/hosts <<END
[Control]
127.0.0.1 ansible_connection=local
END



# MODULOS ANSIBLE 
ansible-galaxy collection install community.mysql
ansible-galaxy collection install community.general



## DATA BASE
db_user_password=$(head -c 500 /dev/urandom | tr -dc 'a-zA-Z0-9' | fold -w 25 | head -n 1)
mysql_root_password=$(head -c 500 /dev/urandom | tr -dc 'a-zA-Z0-9' | fold -w 25 | head -n 1)
user_password=$(head -c 500 /dev/urandom | tr -dc 'a-zA-Z0-9' | fold -w 25 | head -n 1)


# CONFIGURANDO VARIAVEL COM CREDENCIAIS
sed -i "s/dbpass.*/${db_user_password}/" /home/projeto/ansible/vars/vars.yml
sed -i "s/passdbroot.*/${mysql_root_password}/" /home/projeto/ansible/vars/vars.yml
sed -i "s/passuser.*/${user_password}/" /home/projeto/ansible/vars/vars.yml
clear 

# CONFIGURANDO MY.CNF COM CREDENCIAL 
cat > /root/.my.cnf <<END
[client]
user=root
password="${mysql_root_password}"
END



